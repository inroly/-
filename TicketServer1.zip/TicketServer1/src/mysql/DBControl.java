package mysql;

//配置文件读取
import java.io.*;
//Connection
import java.sql.*;
//动态数组
import java.util.ArrayList;
import java.lang.*;


public class DBControl {

    //驱动
    String driver = "com.mysql.jdbc.Driver";
    //URL格式，JavaTest是数据库的名字
    String url = "";
    //数据库连接端口
    String port = "3306";
    //登录的用户名称
    String user = "root";
    //数据库登录密码
    String password = "";
    //连接的数据库名称
    String database = "TicketSytem";
    //创建连接实体
    Connection conn = null;

    //构造函数，连接数据库
    public DBControl() {

//        //读取配置文件
//        try {
//            File configfile = new File("config.txt");
//            if(configfile.isFile() && configfile.exists()) {
//                InputStreamReader isr = new InputStreamReader(new FileInputStream(configfile),"utf8");
//                BufferedReader br = new BufferedReader(isr);
//                String lineTxt = null;
//                int temp = 0;
//                while((lineTxt=br.readLine())!=null) {
//                    if(temp == 0) {
//                        port = lineTxt.split(":")[1];
//                    } else if(temp == 1) {
//                        user = lineTxt.split(":")[1];
//                    } else if(temp == 2) {
//                        password = lineTxt.split(":")[1];
//                    } else if(temp == 3) {
//                        database = lineTxt.split(":")[1];
//                    }
//                    temp ++;
//                }
//                br.close();
//            } else {
//                System.out.println("文件不存在!");
//            }
//        } catch(Exception e) {
//            System.out.println("文件读取错误!");
//        }

        //创建连接数据库URL
        url = "jdbc:mysql://localhost:" + port + "/" + database + "?useUnicode=true&characterEncoding=UTF8&useSSL=false";

        /*
        //创建连接数据库URL
        url = "jdbc:mysql://localhost:3306/" + "TicketSystem" + "?useUnicode=true&characterEncoding=UTF8&useSSL=false";
        user = "root";
        password = "123456";
        */

        //连接数据库
        try {
            //加载驱动程序
            Class.forName(driver);
            conn = (Connection) DriverManager.getConnection(url, user, password);
            if(!conn.isClosed()) {
//                System.out.println("数据库连接成功！");
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

    }

    //关闭连接
    public void close() {
        try {
            this.conn.close();
//            System.out.println("数据库关闭成功！");
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    //插入数据
    public boolean insert(String command) {
        try {
            PreparedStatement preStmt = (PreparedStatement) this.conn.prepareStatement(command);
            preStmt.executeUpdate();
            preStmt.close();
            return true;
        } catch(Exception e) {

            //插入users表中已经存在的username记录
            //更新对应的pass
            //由于主键的存在会抛出异常 因此就在异常中处理
            //在命令中找到两个参数的位置

            //确定是对users数据表进行操作
            if(command.indexOf(" users ") != -1) {
                //找到username的位置
                int index1 = command.indexOf("values(");
                //找到pass的位置
                int index2 = command.indexOf(");");
                //将两个参数剥离出来
                String para = command.substring(index1+7, index2);
                String username = para.split(",")[0];
                String pass = para.split(",")[1];
                //将username的pass更新 调用接口即可
                this.update("update users set pass = " + pass + " where username = " + username + ";");
                return true;
            } else {
                e.printStackTrace();
                return false;
            }
        }
    }
    //查询数据
    public ArrayList<String[]> select(String command) {

        ArrayList<String[]> resultlist = new ArrayList<String[]>();

        try {
            Statement stmt = (Statement) this.conn.createStatement();
            ResultSet rs = (ResultSet) stmt.executeQuery(command);
            ResultSetMetaData data = rs.getMetaData();
            //获取结果的列数 属性的数量
            int ColumnCount = data.getColumnCount();
            //将所有列的名字存储在一个数组中
            String []ColumnName = new String[21];
            for(int i = 0; i < ColumnCount; i++) {
                ColumnName[i] = data.getColumnName(i+1);
            }
            //开始逐行存储结果
            while(rs.next()) {
                String[] raw = new String[21];
                //逐个输出一行信息的所有元素
                //每次输出一个属性
                for(int i = 0; i < ColumnCount; i++) {
                    raw[i] = rs.getString(i+1);
                }
                resultlist.add(raw);
            }
            //释放资源
            rs.close();
            stmt.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
        return resultlist;

    }

    //修改数据
    public boolean update(String command) {
        try {
            PreparedStatement prestmt = (PreparedStatement) this.conn.prepareStatement(command);
            prestmt.executeUpdate();
            //释放资源
            prestmt.close();
            return true;
        } catch(Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //删除数据
    public boolean delete(String command) {
        try {
            PreparedStatement prestmt = (PreparedStatement) this.conn.prepareStatement(command);
            prestmt.executeUpdate();
            //释放资源
            prestmt.close();
            return true;
        } catch(Exception e) {
            e.printStackTrace();
            return false;
        }
    }

}